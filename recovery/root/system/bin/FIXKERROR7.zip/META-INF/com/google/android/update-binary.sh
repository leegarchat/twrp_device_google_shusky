#!/sbin/sh

OUTFD="$2"
FOLDER=/dev/Lite-RW
ui_print(){
        echo -e "ui_print $1\nui_print" >>"/proc/self/fd/$OUTFD"
}



if ! mointpoint /metadata ; then
  mount /metadata
fi

if ! mointpoint /metadata ; then
  ui_print "- Error fixing"
  exit 20
fi

rm -rf /metadata/ota

umount /metadata
ui_print "- Kerror 7 FIXED, now u can flash a ROM"